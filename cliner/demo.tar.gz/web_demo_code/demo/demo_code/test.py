
import subprocess
import os

"""
used for testing ...
"""

os.environ["CLINER_DIR"] = "/data1/cliner_build/demo_build/CliNER"

activate_this = "/data1/cliner_build/venv/bin/activate_this.py"

execfile(activate_this, dict(__file__=activate_this))

proc = subprocess.Popen(["python", "/data1/cliner_build/cliner_web_writer/web_writer.py"], stdin=subprocess.PIPE)

print proc.communicate(input=open("test_input.txt", "rb").read())[0]


