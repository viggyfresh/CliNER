#!/usr/bin/python
from flask import Flask
from flask import render_template
from flask import request
from flask import Markup

import sys

app = Flask(__name__)

# limit input size
app.config['MAX_CONTENT_LENGTH'] = 2048
sys.path.append("/data1/cliner_build/demo_build/CliNER/cliner")

import client

@app.route('/')
def home():
    return render_template( 'demo.html' )

@app.route('/', methods=['POST'])
def demo_page():

    cliner_input = request.form['user_input']

    taggings = client.predict(cliner_input)

    taggings = Markup(taggings)

    return render_template( 'demo.html', cliner_xml_output = taggings)

if __name__ == "__main__":
    exit("Must be imported...")

