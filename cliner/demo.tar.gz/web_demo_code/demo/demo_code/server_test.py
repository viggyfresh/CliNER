
import sys

sys.path.append("/data1/cliner_build/demo_build/CliNER/cliner")

import client

client.predict(

"""
BRIEF HISTORY:

The patient is an (XX)-year-old female with history of previous stroke; hypertension; COPD, stable; renal carcinoma. CT of the maxillofacial area showed no facial bone fracture. Echocardiogram showed normal left ventricular function. She was set up with a skilled nursing facility, where she was to be given daily physical therapy.
"""

)

