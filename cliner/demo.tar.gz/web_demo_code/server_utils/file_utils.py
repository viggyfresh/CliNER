
import os

os.environ["CLINER_DIR"] = "/data1/cliner_build/demo_build/CliNER"
tmp_dir = os.path.join(os.environ["CLINER_DIR"], "cliner/tmp_files_dir")

def write_to_file(f_path, data):

    f = open(f_path, "w")
    f.write(data)
    f.close()

def read_data_from_file(f_path):

    f = open(f_path, "r")
    data = f.read()
    f.close()

    return data

def get_root_file_name(f_path):

    return os.path.splitext(os.path.basename(f_path))[0]

def get_dir_of_file(f_path):

    return os.path.dirname(f_path)


