
# NOTES: problem -> red, test -> navy blue, treatment -> green

# tags: <problem>, <test>, <treatment>

import re

open_tag_problem   = "<problem>"
open_tag_treatment = "<treatment>"
open_tag_test      = "<test>"

# &lt; will display < and &gt; will display >
open_tag_problem_text = "&lt;problem&gt;"
open_tag_treatment_text = "&lt;treatment&gt;"
open_tag_test_text = "&lt;test&gt;"

close_tag_problem   = "</problem>"
close_tag_treatment = "</treatment>"
close_tag_test      = "</test>"

close_tag_problem_text =  "&lt;/problem&gt;"
close_tag_treatment_text = "&lt;/treatment&gt;"
close_tag_test_text = "&lt;/test&gt;"

open_font_color_tag  =  "<font color=\"{0}\">"
red_tag              =  open_font_color_tag.format("#FF0000")
blue_tag             =  open_font_color_tag.format("#1919C1")
green_tag            =  open_font_color_tag.format("#33CC33")
close_font_color_tag =  "</font>"

tag_color_matchings = ((red_tag, open_tag_problem, close_tag_problem, open_tag_problem_text, close_tag_problem_text),
                       (green_tag, open_tag_treatment, close_tag_treatment, open_tag_treatment_text, close_tag_treatment_text),
                       (blue_tag, open_tag_test, close_tag_test, open_tag_test_text, close_tag_test_text))

def color_coat(output):


    for color_tag, open_tag, close_tag, open_tag_text, close_tag_text in tag_color_matchings:

        output = re.sub(open_tag, color_tag + open_tag_text, output)
        output = re.sub(close_tag, close_tag_text + close_font_color_tag, output)

    return output

if __name__ == "__main__":
    exit("not meant to be imported")
    #print color_coat( "the man has <problem>diabetes</problem>")
    #print color_coat( "the doctor performed a <treatment>surgical procedure</treatment>. the procedure was a <test>biopsy</test>")
    #print color_coat( "<problem>this</problem>   <problem> is </problem>   a  <test>test</test>")


