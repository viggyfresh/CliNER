
import subprocess
import sys
import tempfile
import os
import shutil

from input_processing import pre_processor
from input_processing.post_processor import color_coat

os.environ["CLINER_DIR"] = "/data1/cliner_build/demo_build/CliNER"
tmp_dir = os.path.join(os.environ["CLINER_DIR"], "cliner/tmp_files_dir")


def write_to_file(f_path, data):

    f = open(f_path, "w")
    f.write(data)
    f.close()

def read_data_from_file(f_path):

    f = open(f_path, "r")
    data = f.read()
    f.close()

    return data

def get_root_file_name(f_path):

    return os.path.splitext(os.path.basename(f_path))[0]

def get_dir_of_file(f_path):

    return os.path.dirname(f_path)

user_input = str(sys.stdin.read())

user_input = pre_processor.tokenize_input(user_input)

#create tmp files and tmp dir for predict input and output
stdout                   = tempfile.mkstemp(dir=tmp_dir, suffix=".stdout")
stdout_file_no           = stdout[0]
stdout_file_path         = stdout[1]

predict_input_file_path  = tempfile.mkstemp(dir=tmp_dir, suffix=".txt")[1]
predict_output_dir_path  = tempfile.mkdtemp(dir=tmp_dir)

predict_output_file_name = get_root_file_name(predict_input_file_path) + ".con"
predict_output_file_path = os.path.join(predict_output_dir_path, predict_output_file_name)

format_output_file_name  = get_root_file_name(predict_input_file_path) + ".xml"
format_output_file_path  = os.path.join(predict_output_dir_path, format_output_file_name)

# store user input
write_to_file(predict_input_file_path, user_input)

# predict on user input
subprocess.call(["cliner", "predict", predict_input_file_path, "--out", predict_output_dir_path, "--format", "i2b2"], stdout=stdout_file_no)

#subprocess.call(["cliner", "predict", predict_input_file_path, "--out", predict_output_dir_path, "--format", "i2b2"])

con_data = read_data_from_file(predict_output_file_path)
output = read_data_from_file( predict_input_file_path )

#print output

# nothing was predicted evaluate will not do anything....
if len(con_data) > 1:

    subprocess.call(["cliner", "format", predict_input_file_path, "--format", "xml", "--annotations", predict_output_file_path, "--out", format_output_file_path], stdout=stdout_file_no)
#    subprocess.call(["cliner", "format", predict_input_file_path, "--format", "xml", "--annotations", predict_output_file_path, "--out", format_output_file_path])

    output = read_data_from_file(format_output_file_path)

    output = color_coat(output)

# free space
os.remove(stdout_file_path)
os.remove(predict_input_file_path)
shutil.rmtree(predict_output_dir_path)

# print results of predicting in xml format
sys.stdout.flush()
sys.stdout.write(str(output))

#EOF

