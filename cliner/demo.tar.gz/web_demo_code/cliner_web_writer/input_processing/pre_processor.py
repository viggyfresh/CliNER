
import os
import cPickle
import re

from nltk.tokenize import word_tokenize

dir_of_tokenizers = "/data1/cliner_build"

def load_sent_tokenizer():

    sent_tokenizer = None

    p_of_tokenizer = os.path.join(dir_of_tokenizers, "sent_tokenizer.p")

    if not os.path.isfile(p_of_tokenizer):
        from nltk.data import load

        sent_tokenizer = load('tokenizers/punkt/english.pickle')

        f = open(p_of_tokenizer, "wb")
        cPickle.dump(sent_tokenizer, f)
        f.close()

    else:
        f = open(p_of_tokenizer, "rb")
        data = f.read()
        f.close()

        sent_tokenizer = cPickle.loads(data)

    return sent_tokenizer

sent_tokenizer = load_sent_tokenizer()

def tokenize_sent(sent):

    # split block of text into sentences
    return sent_tokenizer.tokenize(sent)

def tokenize(sent):
    """ Split the sentence into tokens """
    toks = word_tokenize(sent)

    # Second pass, delimit on token-combiners such as '/' and '-'
#    delims = ['/', '-', '(', ')', ',', '.', ':', '*', '[', ']', '%', '+']
    delims = ['/', '(', ')', ',', '.', ':', '*', '[', ']', '%', '+']
    for delim in delims:
        retVal = []
        for tok in toks:
            line_split = tok.split(delim)
            if line_split[0] != '': retVal.append(line_split[0])
            for t in line_split[1:]:
                retVal.append(delim)
                if t != '': retVal.append(t)
        toks = retVal

    return retVal

def tokenize_input(text):

    # NOTE: for now there is an issue when blank lines appear when using format.py.
    text = re.sub("\n+", "\n", text)

    sentences = []

    for sentence in tokenize_sent(text):
        sentences.append(" ".join(tokenize(sentence)))

    return "\n".join(sentences)

if __name__ == "__main__":
    exit("not meant to be imported")

#EOF

