import socket
import subprocess
import errno
import time

import os
import sys

HOST, PORT = 'localhost', 2015

import tempfile

os.environ["CLINER_DIR"] = "/data1/cliner_build/demo_build/CliNER"

def connect():

    # SOCK_STREAM == a TCP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    #print "connecting to server..."
    sock.connect((HOST, PORT))

    return sock

def start_server():

    tmp_dir = os.path.join(os.environ["CLINER_DIR"], "cliner/tmp_files_dir")

    stdout                   = tempfile.mkstemp(dir=tmp_dir, suffix=".stdout")
    stdout_file_no           = stdout[0]
    stdout_file_path         = stdout[1]

    #print "setting up server..."

    try:
        pid = os.fork()
        if pid > 0:
            return
        else:
            p = subprocess.Popen(["python", "/data1/cliner_build/demo_build/CliNER/cliner/cliner_server.py"], stdout=stdout_file_no)
            sys.exit(0)

    except OSError, e:
        #print "fork failed..."
        sys.exit(1)

# takes in text for prediction.
def predict(string):

    try:

        sock = connect()

    # only concerned with server not being up.
    except socket.error as serr:

        if serr.errno != errno.ECONNREFUSED:

            raise serr

        else:

            start_server()
            time.sleep(10)
            sock = connect()

    sock.send(string)

    reply = sock.recv(16384)  # limit reply to 16K
    sock.close()

    return reply

if __name__ == "__main__":
    exit()

#print predict(open("/data1/cliner_build/demo_build/CliNER/tokenized_input.txt", "rb").read())

#EOF

