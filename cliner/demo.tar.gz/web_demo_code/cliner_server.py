#! /usr/bin/env python
import SocketServer
import sys
import os
from notes.note import Note
from model import Model


from server_utils import file_utils
from server_utils.input_processing import pre_processor
from server_utils.input_processing import post_processor

import shutil
import tempfile

HOST = "localhost"
PORT = 2015

# where temp files generated will be saved.
os.environ["CLINER_DIR"] = "/data1/cliner_build/demo_build/CliNER"
tmp_dir = os.path.join(os.environ["CLINER_DIR"], "cliner/tmp_files_dir")

# only one model is needed for the server.
model_path = "/data1/cliner_build/demo_build/CliNER/models/run.model"

# trained model
#print "loading trained model"
model = Model.load(model_path)
#print "finished loading model"

def predict(user_input):

    user_input = pre_processor.tokenize_input(str(user_input))

    # generate random files and dirs for temp storage, will be deleted.
    predict_input_file_path  = tempfile.mkstemp(dir=tmp_dir, suffix=".txt")[1]
    predict_output_dir_path  = tempfile.mkdtemp(dir=tmp_dir)

    predict_output_file_name = file_utils.get_root_file_name(predict_input_file_path) + ".con"
    predict_output_file_path = os.path.join(predict_output_dir_path, predict_output_file_name)

    # store user input
    file_utils.write_to_file(predict_input_file_path, user_input)

    format = "i2b2"
    output_dir = predict_output_dir_path
    files = [predict_input_file_path]

    # For each file, predict concept labels
    n = len(files)
    for i,txt in enumerate(sorted(files)):

        # Read the data into a Note object
        note = Note(format)
        note.read(txt)

#        print '-' * 30
 #       print '\n\t%d of %d' % (i+1,n)
  #      print '\t', txt, '\n'

        # Predict concept labels
        labels = model.predict(note)

        # Get predictions in proper format
        extension = note.getExtension()
        output = note.write(labels)

        # Output file
        fname = os.path.splitext(os.path.basename(txt))[0] + '.' + extension
        out_path = os.path.join(output_dir, fname)

        # Output the concept predictions
   #     print '\n\nwriting to: ', out_path
        with open(out_path, 'w') as f:
            print >>f, output
    #    print

        con_data = file_utils.read_data_from_file(predict_output_file_path)
        output = file_utils.read_data_from_file( predict_input_file_path )

#        print con_data

        # nothing was predicted evaluate will not do anything....
        if len(con_data) > 1:

            output = xml_format(predict_input_file_path, predict_output_file_path, "xml")
            output = post_processor.color_coat(output)

    # free space
    os.remove(predict_input_file_path)
    shutil.rmtree(predict_output_dir_path)

    return output

def xml_format(txt, annotations, format):

    # Automatically find the input file format
    in_extension =  os.path.splitext(annotations)[1][1:]
    for f,ext in Note.dictOfFormatToExtensions().items():
        if ext == in_extension:
            in_format = f

    # Read input data into note object
    in_note = Note(in_format)
    in_note.read(txt,annotations)

    # Convert data to standard format
    internal_output = in_note.write_standard()

    tmp_file = tempfile.mkstemp(dir=tmp_dir, suffix="format_temp")[1]

    with open(tmp_file, 'w') as f:
        f.write(internal_output)

    # Read internal standard data into new file with given output format
    out_note = Note(format)
    out_note.read_standard(txt,tmp_file)

    # Output data
    out = out_note.write()

    # Clean up
    os.remove(tmp_file)

    return out

class SingleTCPHandler(SocketServer.BaseRequestHandler):
    #"One instance per connection.  Override handle(self) to customize action."
    def handle(self):
        # self.request is the client connection

        data = self.request.recv(1024)  # clip input at 1Kb

        output = predict(data)

        self.request.send(str(output))
        self.request.close()


class ClinerServer(SocketServer.ThreadingMixIn, SocketServer.TCPServer):

    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, server_address, RequestHandlerClass):
        SocketServer.TCPServer.__init__(self, server_address, RequestHandlerClass)


if __name__ == "__main__":
    server = ClinerServer((HOST, PORT), SingleTCPHandler)
    # terminate with Ctrl-C
    try:
     #   print "running server..."
        server.serve_forever()
    except KeyboardInterrupt:
        sys.exit(0)
else:
    exit("not meant to be imported")


